import os

# Text
whatiwilldo = "What I will do\n[1] Host Minecraft server\n[2] Host site\n[3] Run custom ngrok command\n>>> "
whatportisit = "Enter port:\n>>> "

# Banner
current_directory = os.path.dirname(os.path.abspath(__file__))
banner_path = os.path.join(current_directory, '..', 'banner', 'banner2.txt')
banner3_path = os.path.join(current_directory, '..', 'banner', 'banner3.txt')

# Read banner from file
with open(banner_path, 'r', encoding='utf-8') as file:
    banner2 = file.read()
with open(banner3_path, 'r', encoding='utf-8') as file:
    banner3 = file.read()

# Input & print
print(banner2)
choice = input(whatiwilldo)

# Ensure the choice is a valid option
if choice not in ["1", "2", "3"]:
    print("Invalid choice. Please select a valid option (1-3).")
else:
    if choice in ["1", "2"]:
        port = input(whatportisit)

    # Commands
    cls = "clear"  # Change to "cls" on Windows

    if choice == "1":
        os.system(cls)
        print(banner3)
        os.system(f"ngrok tcp {port}")  # Start the Minecraft server
    elif choice == "2":
        os.system(cls)
        print(banner2)
        os.system(f"ngrok http {port}")   # Start the website
    elif choice == "3":
        os.system(cls)
        print(banner2)
        while True:
             my = input("Enter your custom ngrok command (type 'exit' to return):\n>>> ")
             if my == "exit":
                 break
             os.system(my)  # Run the custom ngrok command
